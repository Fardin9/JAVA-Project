	import java.util.*;
	import java.lang.*;
	import java.io.*;
	import javax.swing.*;  
	import java.awt.event.*;
	import java.awt.*;
	import java.sql.*;
	import java.awt.Color;
	import javax.swing.JScrollPane;
	import javax.swing.JOptionPane;
class Parentupdate{
	public Parentupdate(){
		JFrame f=new JFrame("UPDATE");
		f.getContentPane().setBackground(Color.BLUE);
		JLabel l1,l2;
		JTextField f1,f2;
		
				l1=new JLabel("ID");
		  l1.setBounds(420,175,300,70);
          l1.setForeground(Color.BLACK);
          l1.setBackground(Color.WHITE);
		f1=new JTextField("");
		f1.setBounds(520,200, 200, 20);
		f.add(l1);f.add(f1);	
		
		
		
		
		
		
		l2=new JLabel("PASSWORD");
		  l2.setBounds(420,225,300,70);
          l2.setForeground(Color.BLACK);
          l2.setBackground(Color.WHITE);
		f2=new JTextField("");
			f2.setBounds(520,250, 200, 20);
		f.add(l2);f.add(f2);	
		
		JButton b1=new JButton("UPDATE");
				b1.setBounds(450,600,90,35);
                b1.setForeground(Color.BLACK);
                b1.setBackground(Color.GREEN);
                f.add(b1);
					
				JButton b2=new JButton("BACK");
				b2.setBounds(600,600,90,35);
                b2.setForeground(Color.BLACK);
                b2.setBackground(Color.RED);
                f.add(b2); 
				
				f.setSize(1000,900);//400 width and 500 height  
			f.setLayout(null);//using no layout managers  
			f.setVisible(true);//making the frame visible  
			f.setBackground(Color.decode("#058dc7"));
				
			 b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
				try{
                Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	String sql="update parent set password='"+f2.getText()+"' where id='"+f1.getText()+"'";
             ;
		stmt.executeUpdate(sql);
		con.close();
			    f.setVisible(false);
                Parentlist pl=new Parentlist();			
			}
			catch(Exception e){
				System.out.println(e);
				
				
			}
			}
				
                 
         });
		 
		  b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
               f.setVisible(false);
               Parentlist pl=new Parentlist();
             }
         });
	}
}
                