	import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
	
	
	
	
	import java.util.*;
	import java.lang.*;
	import java.io.*;
	import javax.swing.*;  
	import java.awt.event.*;
	import java.awt.*;
	import javax.swing.JOptionPane;
	import javax.swing.JScrollPane;
		
	
class Staffhome{
	
    static boolean setVisible;
    JLabel Name;
    JLabel Id;
    JLabel Mobile;
    JLabel Timing;
    JLabel Place;
    JLabel Salary;
	JLabel Position;
    
    JLabel a;
    JLabel b;
    JLabel c;
    JLabel d;
    JLabel e;
    JLabel t;
    JLabel g;
    
   
    JButton sb;
    JButton Em;
	
   
 public Staffhome(String id){
	 
	  
	      
       JFrame f=new JFrame("STAFF INFORMATION ");
        f.setLayout(null);
		f.setVisible(true);
        f.getContentPane().setBackground(Color.BLACK);
        f.setSize(1500,750);
       // f.setLocation(0,0);
        
        JLabel title = new JLabel("Home");
        f.add(title);
        title.setBounds(520,50,550,30);
        title.setForeground(Color.YELLOW);
        title.setBackground(Color.YELLOW);
        title.setFont(new Font("Tahoma",Font.BOLD,30));
    
       Name = new JLabel("STAFF NAME:");
       Name.setBounds(500,100,300,70);
       Name.setForeground(Color.WHITE);
       Name.setBackground(Color.WHITE);
       f.add(Name);
       
       a= new JLabel("name");
        a.setBounds(700,100,300,70);
        a.setForeground(Color.WHITE);
        a.setBackground(Color.WHITE);
        a.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add(a);
       
       
      
        Id = new JLabel("ID:");
       Id.setBounds(500,150,300,70);
       Id.setForeground(Color.WHITE);
       Id.setBackground(Color.WHITE);
       f.add(Id);
       
       b= new JLabel("id");
        b.setBounds(700,150,300,70);
        b.setForeground(Color.WHITE);
        b.setBackground(Color.WHITE);
        b.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add(b);
       
      
      
       
       
       Mobile= new JLabel("Phone Number:");
        Mobile.setBounds(500,200,300,70);
        Mobile.setForeground(Color.WHITE);
        Mobile.setBackground(Color.WHITE);
       f.add( Mobile);
       
       c= new JLabel("mobile");
        c.setBounds(700,200,500,70);
        c.setForeground(Color.WHITE);
        c.setBackground(Color.WHITE);
        c.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add( c);
       
       
       
     
      Timing = new JLabel("Timing:");
       Timing.setBounds(500,250,250,70);
      Timing.setForeground(Color.WHITE);
       Timing.setBackground(Color.WHITE);
       f.add(Timing);
       
       d= new JLabel("timing");
        d.setBounds(700,250,250,70);
        d.setForeground(Color.WHITE);
        d.setBackground(Color.WHITE);
        d.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add(d);
       
        Place = new JLabel("Place:");
       Place.setBounds(500,300,300,70);
       Place.setForeground(Color.WHITE);
       Place.setBackground(Color.WHITE);
       f.add(Place);
       
       e= new JLabel("place");
        e.setBounds(700,300,300,70);
        e.setForeground(Color.WHITE);
        e.setBackground(Color.WHITE);
        e.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add(e);
        Salary = new JLabel("Salary:");
       Salary.setBounds(500,350,300,70);
       Salary.setForeground(Color.WHITE);
      Salary.setBackground(Color.WHITE);
      f.add(Salary);
       
       t= new JLabel("salary");
        t.setBounds(700,350,300,70);
        t.setForeground(Color.WHITE);
        t.setBackground(Color.WHITE);
        t.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add(t);
        Position = new JLabel("Position:");
       Position.setBounds(500,400,300,70);
       Position.setForeground(Color.WHITE);
      Position.setBackground(Color.WHITE);
       f.add(Position);
       
        g= new JLabel("position");
        g.setBounds(700,400,300,70);
        g.setForeground(Color.WHITE);
        g.setBackground(Color.WHITE);
        g.setFont(new Font("Tahoma",Font.BOLD,15));
        f.add(g);
    
        
       
        
       sb=new JButton(" Logout");
       sb.setBounds(990,10,90,35);
       sb.setForeground(Color.WHITE);
       sb.setBackground(Color.RED);
       f.add(sb);
      
       
       
       
       
       sb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                f.setVisible(false);
               Login l=new Login();
            }
            
            
            
                });
       
   
            
            
       
       
         try{
				Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	
	
	String selectQuery=("select * from staffinfo where id="+id);	
	ResultSet rs=stmt.executeQuery(selectQuery);	   	          
            if(rs.next()){
                    a.setText(rs.getString("NAME"));
                    b.setText(rs.getString("ID"));
                    c.setText(rs.getString("Mobile"));
                    d.setText(rs.getString("timing"));
                    e.setText(rs.getString("place"));
                    t.setText(rs.getString("salary"));
                    g.setText(rs.getString("position"));
                   
                   
                  
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            
        }
        
          
             
            
        
    }
}
