	import java.util.*;
	import java.lang.*;
	import java.io.*;
	import javax.swing.*;  
	import java.awt.event.*;
	import java.awt.*;
	import java.sql.*;
	import javax.swing.JComboBox;
	
class Studenthome{
    static boolean setVisible;
    JLabel Name;
    JLabel Id;
    JLabel Phonenumber;
    JLabel Address;
    JLabel fname;
    JLabel mname;
    JLabel Cgpa;
    
    JLabel a;
    JLabel b;
    JLabel c;
    JLabel d;
    JLabel e;
    JLabel t;
    JLabel g;
    JLabel h;
    JLabel i;
   
    JButton sb;
    JButton Em;
   
  public  Studenthome (String id){
        
        JLabel title = new JLabel("Home");
        f.add(title);
        title.setBounds(520,50,550,30);
        title.setForeground(Color.YELLOW);
        title.setBackground(Color.YELLOW);
        title.setFont(new Font("Tahoma",Font.BOLD,30));
    
       Name = new JLabel("STUDENT NAME:");
       Name.setBounds(500,100,300,70);
       Name.setForeground(Color.WHITE);
       Name.setBackground(Color.WHITE);
       f.add(Name);
       
       a= new JLabel("name");
        a.setBounds(700,100,300,70);
        a.setForeground(Color.WHITE);
        a.setBackground(Color.WHITE);
        a.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add( a);
       
       
      
        Id = new JLabel("Student ID:");
       Id.setBounds(500,150,300,70);
       Id.setForeground(Color.WHITE);
       Id.setBackground(Color.WHITE);
       f.add(Id);
       
       b= new JLabel("id");
        b.setBounds(700,150,300,70);
        b.setForeground(Color.WHITE);
        b.setBackground(Color.WHITE);
        b.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add( b);
       
      
      
       
       
       Phonenumber= new JLabel("Phone Number:");
        Phonenumber.setBounds(500,200,300,70);
        Phonenumber.setForeground(Color.WHITE);
        Phonenumber.setBackground(Color.WHITE);
       f.add( Phonenumber);
       
       c= new JLabel("Phone_Number");
        c.setBounds(700,200,500,70);
        c.setForeground(Color.WHITE);
        c.setBackground(Color.WHITE);
        c.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add( c);
       
       
       
     
       Cgpa = new JLabel("Cgpa:");
       Cgpa.setBounds(500,250,250,70);
       Cgpa.setForeground(Color.WHITE);
       Cgpa.setBackground(Color.WHITE);
       f.add(Cgpa);
       
       d= new JLabel("Cgpa");
        d.setBounds(700,250,250,70);
        d.setForeground(Color.WHITE);
        d.setBackground(Color.WHITE);
        d.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add( d);
       
        fname = new JLabel("Father Name:");
       fname.setBounds(500,300,300,70);
       fname.setForeground(Color.WHITE);
       fname.setBackground(Color.WHITE);
       f.add(fname);
       
       e= new JLabel("Father_Name");
        e.setBounds(700,300,300,70);
        e.setForeground(Color.WHITE);
        e.setBackground(Color.WHITE);
        e.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add( e);
        mname = new JLabel("Mother Name:");
       mname.setBounds(500,350,300,70);
       mname.setForeground(Color.WHITE);
       mname.setBackground(Color.WHITE);
      f.add(mname);
       
       t= new JLabel("Mother_Name");
        f.setBounds(700,350,300,70);
        f.setForeground(Color.WHITE);
        f.setBackground(Color.WHITE);
        f.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add(t);
        Address = new JLabel("Address:");
       Address.setBounds(500,400,300,70);
       Address.setForeground(Color.WHITE);
       Address.setBackground(Color.WHITE);
       f.add(Address);
       
        g= new JLabel("Address");
        g.setBounds(700,400,300,70);
        g.setForeground(Color.WHITE);
        g.setBackground(Color.WHITE);
        g.setFont(new Font("Tahoma",Font.BOLD,15));
        f.add(g);
        
       JFrame f=new JFrame("STUDENT INFORMATION ");
        f.setLayout(null);
        f.getContentPane().setBackground(Color.BLACK);
        f.setSize(1500,750);
        f.setLocation(0,0);
        
       
        
       sb=new JButton(" Logout");
       sb.setBounds(990,10,90,35);
       sb.setForeground(Color.WHITE);
       sb.setBackground(Color.RED);
       f.add(sb);
        String [] emailStrings= {"","Alom Ahmed","Marzia Bagom","Enayet Ullah"};
       JComboBox cmbEmailList= new JComboBox(emailStrings);
        h = new JLabel("");
        cmbEmailList.setSelectedIndex(0);
        cmbEmailList.setVisible(true);
        cmbEmailList.setBounds(900, 200, 200, 20);
        cmbEmailList.setForeground(Color.BLUE);
        cmbEmailList.setBackground(Color.GREEN);
        f.add(cmbEmailList);
        h.setForeground(Color.ORANGE);
        h.setBounds(900,220,300,70);
        h.setBackground(Color.WHITE);
        f.add(h);
        i= new JLabel("Email Id:");
        i.setBounds(900,150,300,70);
        i.setForeground(Color.BLUE);
        i.setBackground(Color.BLUE);
        i.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add( i);
       
       
       
       
       sb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                f.setVisible(false);
               Login l=new Login();
            }
            
            
            
                });
       
        cmbEmailList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                try{
						Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 

	String selectQuery=("select * from teacher_mail");
	
	ResultSet rs=stmt.executeQuery(selectQuery);					
                        
                while(rs.next()){
                if(cmbEmailList.getSelectedItem().equals(""))
                    
                {
                     h.setText("");
                }
                    else if(cmbEmailList.getSelectedItem().equals("Alom Ahmed"))
                    {
                        h.setText("aahmed@yahoo.com");
                    }
                else if(cmbEmailList.getSelectedItem().equals("Marzia Bagom"))
                    {
                        h.setText("marzia@gmail.com");
                    }
                else if(cmbEmailList.getSelectedItem().equals("Enayet Ullah"))
                    {
                    h.setText("ullahen@hotmail.com");
                    }
              
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(e);
        
    }                                          
            }
            
            
            
                });
       
       
         try{
				Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	
	
	String selectQuery=("select * from studentinfo where id='"+id+"'");	
	ResultSet rs=stmt.executeQuery(selectQuery);	   	          
            if(rs.next()){
                    a.setText(rs.getString("NAME"));
                    b.setText(rs.getString("ID"));
                    c.setText(rs.getString("Phone"));
                    d.setText(rs.getString("Cgpa"));
                    e.setText(rs.getString("Father"));
                    f.setText(rs.getString("Mother"));
                    g.setText(rs.getString("Address"));
                   
                   
                  
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            
        }
        
          
             
            
        
    }
}
