	import java.util.*;
	import java.lang.*;
	import java.io.*;
	import javax.swing.*;  
	import java.awt.event.*;
	import java.awt.*;
	import java.sql.*;
	import java.awt.Color;
	import java.awt.Font;
class Teacherhome{
	public Teacherhome(String id){
		JFrame f=new JFrame("Teacher HOME");
		JButton b1=new JButton("STUDENT LIST");
		b1.setBounds(100,50,150,50);
		JButton b3=new JButton("SCHEDULE");
		b3.setBounds(100,150,150,50);
		
		JButton b2=new JButton("LOG OUT");
		b2.setBounds(400,50,150,50);
		f.getContentPane().setBackground(Color.BLACK);
		f.add(b1);f.add(b2);f.add(b3);
		f.setSize(650,500);//400 width and 500 height  
    f.setLayout(null);//using no layout managers  
    f.setVisible(true);//making the
	
	
				b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				Studentlist sl=new Studentlist();
				
			}
		});
		
		
				b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				Timinglist tl=new Timinglist(id);
				
			}
		});
		

		
			b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				f.setVisible(false);
				Login l= new Login();
				
				
			}
		});
	}

}