	//package school;
	import java.util.*;
	import java.lang.*;
	import java.io.*;
	import javax.swing.*;  
	import java.awt.event.*;
	import java.awt.*;
	import java.sql.*;
	import java.awt.Color;
	import javax.swing.JScrollPane;
	import javax.swing.JOptionPane;
class Parentdelete{
	public Parentdelete(){
		JFrame f=new JFrame("DELETE");
		JLabel l1=new JLabel("Parent ID");
		l1.setBounds(400,170,300,70);
		l1.setForeground(Color.BLACK);
        l1.setBackground(Color.WHITE);
		JTextField f1=new JTextField("");
		f1.setBounds(520,190,200,20);
		f.add(l1);f.add(f1);
		JButton b1=new JButton("DELETE");
		b1.setBounds(380,250,90,35);
		b1.setForeground(Color.BLACK);
        b1.setBackground(Color.GREEN);
        f.add(b1);
		JButton b2=new JButton("BACK");
		b2.setBounds(450,250,90,35);
		b2.setBounds(600,600,90,35);
        b2.setForeground(Color.BLACK);
        b2.setBackground(Color.RED);
        f.add(b2); 
		f.setSize(1000,900);//400 width and 500 height  
			f.setLayout(null);//using no layout managers  
			f.setVisible(true);//making the frame visible  
			f.setBackground(Color.decode("#058dc7"));
		
		b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
				try{
                Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	String sql=("DELETE from parent  WHERE id ='"+f1.getText()+"'");
                
		stmt.executeUpdate(sql);
		con.close();
			    f.setVisible(false);
                Parentlist pl=new Parentlist();			
			}
			catch(Exception e){
				System.out.println(e);
				
				
			}
			}
				
                 
         });
		 
		  b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
               f.setVisible(false);
               Parentlist l=new Parentlist();
             }
         });
	}
}