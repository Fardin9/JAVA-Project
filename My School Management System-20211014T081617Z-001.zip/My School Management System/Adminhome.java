	import java.util.*;
	import java.lang.*;
	import java.io.*;
	import javax.swing.*;  
	import java.awt.event.*;
	import java.awt.*;
	import java.sql.*;
class Adminhome{
	public Adminhome(){
		JFrame f=new JFrame("ADMIN HOME");
		f.getContentPane().setBackground(Color.BLACK);
		JButton b1=new JButton("STUDENT LIST");
		b1.setBounds(400,200,150,50);
		JButton b2=new JButton("TEACHER LIST");
		b2.setBounds(400,50,150,50);
		JButton b3=new JButton("STAFF LIST");
		b3.setBounds(700,50,150,50);
		JButton b4=new JButton("PARENT LIST");
		b4.setBounds(700,200,150,50);
		JButton b5=new JButton("LOG OUT");
		b5.setBounds(700,600,150,50);
		f.add(b1);f.add(b2);f.add(b3);f.add(b4);f.add(b5);
		f.setSize(1500,750);//400 width and 500 height  
    f.setLayout(null);//using no layout managers  
    f.setVisible(true);//making the
	
	
				b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				Studentlist sl=new Studentlist();
				
			}
		});
		
			b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				Stafflist stl=new Stafflist();
				
			}
		});
		
			b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				Teacherlist tl=new Teacherlist();
				
			}
		});
		
		
			b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				f.setVisible(false);
				Parentlist pl= new Parentlist();
				
				
			}
		});
		
		b5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent evt){
				f.setVisible(false);
				Login l=new Login();
			}
		});
	}

}