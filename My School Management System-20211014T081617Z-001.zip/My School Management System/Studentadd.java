	import java.util.*;
	import java.lang.*;
	import java.io.*;
	import javax.swing.*;  
	import java.awt.event.*;
	import java.awt.*;
	import java.sql.*;
	import java.awt.Color;
	import javax.swing.JScrollPane;
	import javax.swing.JOptionPane;
class Studentadd{
	public Studentadd(){
		JFrame f=new JFrame("ADD");
		f.getContentPane().setBackground(Color.BLUE);
		JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9;
		JTextField f1,f2,f3,f4,f5,f6,f7,f8,f9;
		
				l9=new JLabel("Id");
		  l9.setBounds(420,175,300,70);
          l9.setForeground(Color.BLACK);
          l9.setBackground(Color.WHITE);
		f9=new JTextField("");
		f9.setBounds(520,200, 200, 20);
		f.add(l9);f.add(f9);	
		
		
		
		
		
		
		l1=new JLabel("NAME");
		  l1.setBounds(420,225,300,70);
          l1.setForeground(Color.BLACK);
          l1.setBackground(Color.WHITE);
		f1=new JTextField("");
			f1.setBounds(520,250, 200, 20);
		f.add(l1);f.add(f1);	

l2=new JLabel("PASSWORD");
		  l2.setBounds(420,525,300,70);
          l2.setForeground(Color.BLACK);
          l2.setBackground(Color.WHITE);
		f2=new JTextField("");
			f2.setBounds(520,550, 200,20);
		f.add(l2);f.add(f2);		

l3=new JLabel("PHONE");
		  l3.setBounds(420,275,300,70);
          l3.setForeground(Color.BLACK);
          l3.setBackground(Color.WHITE);
		f3=new JTextField("");
			f3.setBounds(520, 300, 200,20);
		f.add(l3);f.add(f3);				
		
l4=new JLabel("CGPA");
		  l4.setBounds(420,325,250,70);
          l4.setForeground(Color.BLACK);
          l4.setBackground(Color.WHITE);
		f4=new JTextField("");
			f4.setBounds(520, 350, 200,20);
		f.add(l4);f.add(f4);			

		
l5=new JLabel("FATHER");
		  l5.setBounds(420,375,300,70);
          l5.setForeground(Color.BLACK);
          l5.setBackground(Color.WHITE);
		f5=new JTextField("");
			f5.setBounds(520, 400, 200,20);
		f.add(l5);f.add(f5);	
		
l6=new JLabel("MOTHER");
		  l6.setBounds(420,425,300,70);
          l6.setForeground(Color.BLACK);
          l6.setBackground(Color.WHITE);
		f6=new JTextField("");
			f6.setBounds(520,450, 200,20);
		f.add(l6);f.add(f6);	

		
l7=new JLabel("ADDRESS");
		  l7.setBounds(420,475,300,70);
          l7.setForeground(Color.BLACK);
          l7.setBackground(Color.WHITE);
		f7=new JTextField("");
			f7.setBounds(520,500,200,20);
		f.add(l7);f.add(f7);

				JButton b1=new JButton("SAVE");
				b1.setBounds(450,600,90,35);
                b1.setForeground(Color.BLACK);
                b1.setBackground(Color.GREEN);
                f.add(b1);
					
				JButton b2=new JButton("BACK");
				b2.setBounds(600,600,90,35);
                b2.setForeground(Color.BLACK);
                b2.setBackground(Color.RED);
                f.add(b2); 
				
				f.setSize(1000,900);//400 width and 500 height  
			f.setLayout(null);//using no layout managers  
			f.setVisible(true);//making the frame visible  
			f.setBackground(Color.decode("#058dc7"));
				
			 b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
				try{
                Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	String sql="INSERT into studentinfo (NAME,password,phone,cgpa,father,mother,address,id) "
                + "VALUES('"+f1.getText()+"','"
                +f2.getText()+"','"+f3.getText()+"','"+f4.getText()
                +"','"+f5.getText()+"','"+f6.getText()+"','"+f7.getText()+"','"+f9.getText()+"')";
		stmt.executeUpdate(sql);
		con.close();
			    f.setVisible(false);
                Studentlist sl=new Studentlist();			
			}
			catch(Exception e){
				System.out.println(e);
				
				
			}
			}
				
                 
         });
		 
		  b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) 
            {
               f.setVisible(false);
               Studentlist sl=new Studentlist();
             }
         });
	}
}
                