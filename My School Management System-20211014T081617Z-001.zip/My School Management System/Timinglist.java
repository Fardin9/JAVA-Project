import java.util.*;
	import java.lang.*;
	import java.io.*;
	import javax.swing.*;  
	import java.awt.event.*;
	import java.awt.*;
	import java.sql.*;
	import javax.swing.JComboBox;
	import javax.swing.JOptionPane;
	import javax.swing.JScrollPane;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.Statement;
		
	
class Timinglist{
	
    static boolean setVisible;
    JLabel Name;
	JLabel Id;
	JLabel Sunday;
    JLabel Monday;
    JLabel Tuesday;
    JLabel Wednesday;
	
	JLabel a;
    JLabel b;
    JLabel c;
    JLabel d;
    JLabel e;
	JLabel g;
	
	public Timinglist(String id){
	 
	  
	      
       JFrame f=new JFrame("MY WEEKLY CLASSES ");
        f.setLayout(null);
		f.setVisible(true);
        f.getContentPane().setBackground(Color.BLACK);
        f.setSize(1500,750);
       // f.setLocation(0,0);
        
        JLabel title = new JLabel("MY SCHEDULE");
        f.add(title);
        title.setBounds(200,50,550,30);
        title.setForeground(Color.YELLOW);
        title.setBackground(Color.YELLOW);
        title.setFont(new Font("Tahoma",Font.BOLD,30));
		 
		 Name = new JLabel("NAME:");
        Name.setBounds(500,20,300,70);
       Name.setForeground(Color.WHITE);
       Name.setBackground(Color.WHITE);
       f.add(Name);
       
       e= new JLabel("name");
        e.setBounds(700,20,300,70);
        e.setForeground(Color.WHITE);
        e.setBackground(Color.WHITE);
        e.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add(e);
	   
	    Id = new JLabel("ID:");
        Id.setBounds(500,50,300,70);
       Id.setForeground(Color.WHITE);
       Id.setBackground(Color.WHITE);
       f.add(Id);
       
       g= new JLabel("id");
       g.setBounds(700,50,300,70);
        g.setForeground(Color.WHITE);
        g.setBackground(Color.WHITE);
        g.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add(g);
       
	   
	   Sunday = new JLabel("SUNDAY:");
        Sunday.setBounds(500,100,300,70);
       Sunday.setForeground(Color.WHITE);
       Sunday.setBackground(Color.WHITE);
       f.add( Sunday);
       
       a= new JLabel("sunday");
        a.setBounds(700,100,300,70);
        a.setForeground(Color.WHITE);
        a.setBackground(Color.WHITE);
        a.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add(a);
       
       
      
        Monday = new JLabel("MONDAY:");
       Monday.setBounds(500,150,300,70);
       Monday.setForeground(Color.WHITE);
       Monday.setBackground(Color.WHITE);
       f.add(Monday);
       
       b= new JLabel("monday");
        b.setBounds(700,150,300,70);
        b.setForeground(Color.WHITE);
        b.setBackground(Color.WHITE);
        b.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add(b);
       
      
      
       
       
      Tuesday= new JLabel("TUESDAY:");
        Tuesday.setBounds(500,200,300,70);
        Tuesday.setForeground(Color.WHITE);
        Tuesday.setBackground(Color.WHITE);
       f.add( Tuesday);
       
       c= new JLabel("tuesday");
        c.setBounds(700,200,500,70);
        c.setForeground(Color.WHITE);
        c.setBackground(Color.WHITE);
        c.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add( c);
       
       
       
     
       Wednesday = new JLabel("WEDNESDAY:");
       Wednesday.setBounds(500,250,250,70);
       Wednesday.setForeground(Color.WHITE);
       Wednesday.setBackground(Color.WHITE);
       f.add(Wednesday);
	   
	    d= new JLabel("wednesday");
        d.setBounds(700,250,250,70);
        d.setForeground(Color.WHITE);
        d.setBackground(Color.WHITE);
        d.setFont(new Font("Tahoma",Font.BOLD,15));
       f.add( d);
	   
	   JButton b4=new JButton("BACK");
		b4.setBounds(990,20,90,35);
		b4.setForeground(Color.WHITE);
		b4.setBackground(Color.RED);
		f.add(b4);
		
		   b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                f.setVisible(false);
              // Teacherhome th=new Teacherhome(id);
            }
            
            
            
                });
		
		 try{
				Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	
	
	String selectQuery=("select * from timing_list where id='"+id+"'");	
	ResultSet rs=stmt.executeQuery(selectQuery);	   	          
            if(rs.next()){
                    e.setText(rs.getString("name"));
				    g.setText(rs.getString("id"));
					a.setText(rs.getString("sunday"));
                    b.setText(rs.getString("monday"));
                    c.setText(rs.getString("tuesday"));
                    d.setText(rs.getString("wednesday"));
				
					
                
                   
                   
                  
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            
        }
	}
}
        
       
      