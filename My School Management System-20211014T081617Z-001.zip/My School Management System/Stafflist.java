	import java.util.*;
	import java.lang.*;
	import java.io.*;
	import javax.swing.*;  
	import java.awt.event.*;
	import java.awt.*;
	import java.sql.*;
	import javax.swing.JOptionPane;
	import javax.swing.JScrollPane;
	import javax.swing.JTable;
	import javax.swing.table.DefaultTableModel;
	import java.awt.Color;
	import javax.swing.table.TableColumn;
class Stafflist{
	JTable c;
    JScrollPane d;
	 static boolean setVisible;
	
	
	public Stafflist(){
		JFrame f=new JFrame("STAFF LIST");
		f.setForeground(Color.black);
		f.setBackground(Color.black);
		f.getContentPane().setBackground(Color.YELLOW);
		JButton b1,b2,b3,b4;
		b1=new JButton("ADD");
		b1.setBounds(600,500,100,45);
		b1.setBackground(Color.WHITE);
		f.add(b1);
		b2=new JButton("UPDATE");
		b2.setBounds(750,500,100,45);
		b2.setBackground(Color.WHITE);
		f.add(b2);
		b3=new JButton("DELETE");
		b3.setBounds(900,500,100,45);
		b3.setBackground(Color.WHITE);
		f.add(b3);
		b4=new JButton("BACK");
		b4.setBounds(900,600,100,45);
		b4.setBackground(Color.WHITE);
		f.add(b4);
	
		
		String [] clm = {"NAME","ID", "PASSWORD","MOBILE","TIMING","PLACE","SALARY","POSITION"};
                        String [][] row ={{},{},{}};
                         c = new JTable(row,clm);
                         d = new JScrollPane(c);
                         d.setBounds(100,50,1090,400);						
                         f.add(d);
						  TableColumn col = c.getColumnModel().getColumn(0);
    int width = 500;
    col.setPreferredWidth(width);
						
						try{
			Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	ResultSet rs=stmt.executeQuery("select * from staffinfo"); 
	 DefaultTableModel model = new DefaultTableModel(new String[]{"NAME","ID", "PASSWORD","MOBILE","TIMING","PLACE","SALARY","POSITION"}, 0);
                     while(rs.next())
                     {
                         String col1 = rs.getString("NAME");
                         String col2 = rs.getString("ID");
                         String col3 = rs.getString("PASSWORD");                
                         String col4 = rs.getString("MOBILE");
                         String col5 = rs.getString("TIMING");
                        String col6 = rs.getString("PLACE");
                        String col7 = rs.getString("SALARY");
						String col8=rs.getString("POSITION");
                      
                      
                         
                         model.addRow(new Object[]{col1, col2, col3, col4,col5,col6,col7,col8});
                     }
                     c.setModel(model);
					 c.setBackground(Color.decode("#058dc7"));
					 c.setFont(new Font("", 1, 15));
						}
						
	 catch(Exception ex){
                     JOptionPane.showMessageDialog(null, ex.getMessage());
                 }   
		
 
	
			f.setSize(1400,1200);//400 width and 500 height  
			f.setLayout(null);//using no layout managers  
			f.setVisible(true);//making the frame visible  
			f.setBackground(Color.decode("#058dc7"));
			
			
			
			 b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
				   f.setVisible(false);
               Staffadd s=new Staffadd();
            }
       
                });
				
				 b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
				   f.setVisible(false);
               Staffupdate n=new Staffupdate();
            }
       
                });
				
					 b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
				   f.setVisible(false);
               Staffdelete w=new Staffdelete();
            }
       
                });
				
			
			 b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
				   f.setVisible(false);
               //Adminhome ah=new Adminhome();
            }
       
                });
	}
}
	
		
