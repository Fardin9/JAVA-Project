	import java.util.*;
	import java.lang.*;
	import java.io.*;
	import javax.swing.*;  
	import java.awt.event.*;
	import java.awt.*;
	import java.sql.*;
	import javax.swing.JOptionPane;
	import java.awt.Color;
	import javax.swing.JScrollPane;
	import java.awt.Font;
	import javax.swing.JPasswordField;

    class Login {  
	 static boolean setVisible;
    public static void main(String[] args) {  
	
	
    JFrame f=new JFrame("SCHOOL MANAGEMENT SYSTEM");//creating instance of JFrame  
	f.getContentPane().setBackground(Color.BLACK);
	f.setBackground(Color.YELLOW);
	JLabel l1,l2,l3,l4;
	l4=new JLabel("SCHOOL MANAGEMENT SYSTEM");
	l4.setBounds(150,370,300,100);
	l4.setForeground(Color.white);
	l4.setFont(new Font("Calibri",Font.BOLD,15));
	l1=new JLabel("WELCOME");
	l1.setBounds(50,10,100,100);
	l1.setForeground(Color.WHITE);
	l1.setFont(new Font("Calibri",Font.BOLD,15));
	JTextField t1,t2;
	//t1=new JPasswordField();
	t2=new JPasswordField();
	t1=new JTextField();
	t1.setBounds(50,130,200,30);
	//t2=new JTextField();
	t2.setBounds(50,210,200,30);
	l2=new JLabel("UserID");
	l2.setForeground(Color.white);
	l2.setFont(new Font("Calibri",Font.BOLD,15));
	l2.setBounds(50,100,100,30);
	l3=new JLabel("Password");
	l3.setForeground(Color.white);
	l3.setFont(new Font("Calibri",Font.BOLD,15));
	l3.setBounds(50,150,100,100);
	//String country[]={"SELECT","ADMIN","STUDENT","TEACHER"};        
    //JComboBox cb1=new JComboBox(country);  
    //cb1.setBounds(150,50,100,50);	
	JButton b=new JButton("LOG IN as ADMIN");
	b.setBounds(50,270,200,30);
	JButton b1=new JButton("LOG IN as TEACHER");
	b1.setBounds(270,270,200,30);
	JButton b2=new JButton("LOG IN as STUDENT");
	b2.setBounds(50,320,200,30);
	JButton b3=new JButton("LOG IN as STAFF");
	b3.setBounds(270,320,200,30);
	JButton b4=new JButton("LOG IN as PARENT");
	b4.setBounds(50,370,200,30);
	
	
	f.add(l1);f.add(l2);f.add(l3);f.add(l3);f.add(l4);
	f.add(t1);f.add(t2);
	//f.add(cb1);
	f.add(b);f.add(b1);f.add(b2);f.add(b3);;f.add(b4);
	f.setSize(550,500);//400 width and 500 height  
    f.setLayout(null);//using no layout managers  
    f.setVisible(true);//making the frame visible  
	
	 b.addActionListener(new ActionListener()
	{
		
		public void actionPerformed(ActionEvent evt){
		try{
			Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	
	String username=t1.getText();
	String password=t2.getText();
	String selectQuery=("select * from login where username='"+username+"' and password='"+password+"'");
	
	ResultSet rs=stmt.executeQuery(selectQuery);
	int x=1;
 while(rs.next()){
	 if(t1.getText().equals(rs.getString("username"))&&t2.getText().equals(rs.getString("password"))){
		 JOptionPane.showMessageDialog(null, "Congratulations!! The operation done successfully.");		 
		Adminhome ah=new Adminhome();
		t1.setText("");t2.setText("");
	x=0;
	break;
		 
		
    
    }
 }
	if(x!=0){
			  
			
			JOptionPane.showMessageDialog(null,"Sorry, username or password error!");
			t1.setText("");t2.setText("");
	}
 }
		
	catch(Exception e){ 
				 //JOptionPane.showMessageDialog(null,e.getMessage());
			System.out.println(e);
			}  
		}
	
	
	
	
	});
	
	
	 b1.addActionListener(new ActionListener()
	{
		
		public void actionPerformed(ActionEvent evt){
		try{
			Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	
	String userid=t1.getText();
	String password=t2.getText();
	String selectQuery=("select * from teacherinfo where id='"+userid+"' and password='"+password+"'");
	
	ResultSet rs=stmt.executeQuery(selectQuery);
	int x=1;
 while(rs.next()){
	 if(t1.getText().equals(rs.getString("id"))&&t2.getText().equals(rs.getString("password"))){
		 JOptionPane.showMessageDialog(null, "Congratulations!! The operation done successfully.");
		t1.setText("");t2.setText("");
		Teacherhome th=new Teacherhome(userid);
	x=0;
	break;
		 
		
    
    }
 }
	if(x!=0){
			  //JOptionPane.showMessageDialog(null,"ERROR");
			
			JOptionPane.showMessageDialog(null,"Sorry, username or password error!");
			t1.setText("");t2.setText("");
	}
 }
		
	catch(Exception e){ 
				 //JOptionPane.showMessageDialog(null,e.getMessage());
			System.out.println(e);
			}  
		}
	
	
	
	
	});
	
	
	
	 b2.addActionListener(new ActionListener()
	{
		
		public void actionPerformed(ActionEvent evt){
		try{
			Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	
	String userid=t1.getText();
	String password=t2.getText();

	String selectQuery=("select * from studentinfo where id='"+userid+"' and password='"+password+"'");
	
	ResultSet rs=stmt.executeQuery(selectQuery);
	int x=1;
 while(rs.next()){
	 if(t1.getText().equals(rs.getString("id"))&&t2.getText().equals(rs.getString("password"))){
		 JOptionPane.showMessageDialog(null, "Congratulations!! The operation done successfully.");
		 t1.setText("");t2.setText("");
		 Studenthome sh=new Studenthome(userid);
	x=0;
	break;
		 
		
    
    }
 }
	if(x!=0){
			  //JOptionPane.showMessageDialog(null,"ERROR");
			
			JOptionPane.showMessageDialog(null,"Sorry, username or password error!");
			t1.setText("");t2.setText("");
	}
 }
		
	catch(Exception e){ 
				 //JOptionPane.showMessageDialog(null,e.getMessage());
			System.out.println(e);
			}  
		}
	
	
	
	
	});
	
	
	 b3.addActionListener(new ActionListener()
	{
		
		public void actionPerformed(ActionEvent evt){
		try{
			Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	
	String userid=t1.getText();
	String password=t2.getText();

	String selectQuery=("select * from staffinfo where id='"+userid+"' and password='"+password+"'");
	
	ResultSet rs=stmt.executeQuery(selectQuery);
	int x=1;
 while(rs.next()){
	 if(t1.getText().equals(rs.getString("id"))&&t2.getText().equals(rs.getString("password"))){
		 JOptionPane.showMessageDialog(null, "Congratulations!! The operation done successfully.");
		 t1.setText("");t2.setText("");
		 Staffhome sh=new Staffhome(userid);
	x=0;
	break;
		 
		
    
    }
 }
	if(x!=0){
			  //JOptionPane.showMessageDialog(null,"ERROR");
			
			JOptionPane.showMessageDialog(null,"Sorry, username or password error!");
			t1.setText("");t2.setText("");
	}
 }
		
	catch(Exception e){ 
				 //JOptionPane.showMessageDialog(null,e.getMessage());
			System.out.println(e);
			}  
		}
	
	
	
	
	});
	
	
		 b4.addActionListener(new ActionListener()
	{
		
		public void actionPerformed(ActionEvent evt){
		try{
			Class.forName("com.mysql.jdbc.Driver");  
    Connection con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/leo","root","");  
    //here mydb is database name, root is username and password  
    Statement stmt=con.createStatement(); 
	
	String userid=t1.getText();
	String password=t2.getText();

	String selectQuery=("select * from parent where id='"+userid+"' and password='"+password+"'");
	
	ResultSet rs=stmt.executeQuery(selectQuery);
	int x=1;
 while(rs.next()){
	 if(t1.getText().equals(rs.getString("id"))&&t2.getText().equals(rs.getString("password"))){
		 JOptionPane.showMessageDialog(null, "Congratulations!! The operation done successfully.");
		 t1.setText("");t2.setText("");
		 Parenthome ph=new Parenthome(userid);
	x=0;
	break;
		 
		
    
    }
 }
	if(x!=0){
			  //JOptionPane.showMessageDialog(null,"ERROR");
			
			JOptionPane.showMessageDialog(null,"Sorry, username or password error!");
			t1.setText("");t2.setText("");
	}
 }
		
	catch(Exception e){ 
				 //JOptionPane.showMessageDialog(null,e.getMessage());
			System.out.println(e);
			}  
		}
	
	
	
	
	});
	
	
	
   
	
	
	
	}
	}

	//java -cp .;mysql-connector-java-5.1.47.jar Login